package exception;

public class SearchException extends Exception {

    public SearchException() {
    }

    public SearchException(String message) {
        super(message);
    }
}