package exception;

public class BaseDirectoryInvalidException extends Exception {

    public BaseDirectoryInvalidException() {
    }
}
